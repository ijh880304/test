package com.test.admin;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.Iterator;
import java.util.List;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;

public class AdminApiTestMain {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		try {
			URL url = new URL("http://jhim-kong-cp01.fgcp-integration.com:8001/default/routes?sort_desc=1&size=30");
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			con.setRequestMethod("GET");
			con.setRequestProperty("Content-Type", "application/json");

			int status = con.getResponseCode();

			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuffer content = new StringBuffer();
			while ((inputLine = in.readLine()) != null) {
				content.append(inputLine);
			}
			in.close();
			
			System.out.println("status : " + status);
			System.out.println("contents : " + content.toString());
			
			DocumentContext jsonContext = JsonPath.parse(content.toString());
//			String jsonpathCreatorName = jsonContext.read("$.data[*].paths[*]");
			List<String> paths = jsonContext.read("$.data[*].paths[*]");
			
			System.out.println("list : ");
			for (String path : paths) {
				System.out.println(path);
			}
			
			
			
			con.disconnect();
		} catch (ProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
